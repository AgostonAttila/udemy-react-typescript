function App() {
  return <h1>Let's get started!</h1>;
}

export default App;
