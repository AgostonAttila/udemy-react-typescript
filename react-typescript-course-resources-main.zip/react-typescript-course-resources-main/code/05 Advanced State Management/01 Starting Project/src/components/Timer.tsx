import Container from './UI/Container.tsx';

export default function Timer() {
  return (
    <Container as="article">
      <h2>TODO: TIMER NAME</h2>
    </Container>
  );
}
