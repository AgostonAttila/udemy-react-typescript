function App() {
  return <h1>Data Fetching!</h1>;
}

export default App;
